$(document).ready(function() {
    // Make all tables striped and bordered
    $("table").each(function() {
      $(this).addClass(['table-striped', 'table-bordered']);
    });
});
